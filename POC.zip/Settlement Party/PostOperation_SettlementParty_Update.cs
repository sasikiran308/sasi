﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace CRM.Plugins.Practice.Settlement_Party
{
    public class PostOperation_SettlementParty_Update : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                Entity entity = (Entity)context.InputParameters["Target"];

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                try
                {
                    tracingService.Trace($"Post Operation SettlementParty Update Execution Started:{DateTime.Now}");
                    Entity postImage = (Entity)context.PostEntityImages["PostImage"];
                    if (postImage.Contains("cdi_settlement"))
                    {
                        Guid id = ((EntityReference)postImage.Attributes["cdi_settlement"]).Id;
                        UpdateSettlementRecord(service, id);
                    }

                    tracingService.Trace($"Post Operation SettlementParty Update Execution Ended:{DateTime.Now}");
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in Post Operation SettlementParty Update.", ex);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Plugin: {0}", ex.ToString());
                    throw;
                }
            }
        }
        private void UpdateSettlementRecord(IOrganizationService service, Guid id)
        {
            string fetchxml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                  "<entity name='cdi_settlementparty'>" +
                                    "<attribute name='cdi_settlementpartyid' />" +
                                    "<attribute name='cdi_name' />" +
                                    "<attribute name='createdon' />" +
                                    "<attribute name='cdi_emailaddress' />" +
                                    "<attribute name='cdi_datesigned' />" +
                                    "<order attribute='cdi_name' descending='false' />" +
                                    "<filter type='and'>" +
                                      "<condition attribute='cdi_settlement' operator='eq' uiname='' uitype='cdi_settlement' value='" + id + "' />" +
                                    "</filter>" +
                                  "</entity>" +
                                "</fetch>";
            EntityCollection entityCollection = service.RetrieveMultiple(new FetchExpression(fetchxml));
            bool isDataExists = false;
            if (entityCollection != null && entityCollection.Entities != null && entityCollection.Entities.Count > 0)
            {
                foreach (var entity in entityCollection.Entities)
                {
                    if (entity.Contains("cdi_emailaddress") && entity.Contains("cdi_datesigned"))
                    {
                        isDataExists = true;
                    }
                }
            }
            if (isDataExists == true)
            {
                Entity settlement = new Entity("cdi_settlement");
                settlement.Id = id;
                settlement["cdi_allsettlementpartiessigned"] = true;
                settlement["statuscode"] = new OptionSetValue(3);
                service.Update(settlement);              
            }            
        }

    }
}

