﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace CRM.Plugins.Practice.Settlement
{
    public class PostOperation_Settlement_UpdateRecord : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                Entity entity = (Entity)context.InputParameters["Target"];

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                try
                {
                    tracingService.Trace($"Post Operation Settlement UpdateRecord Execution Started:{DateTime.Now}");
                    Entity postImage = (Entity)context.PostEntityImages["PostImage"];
                    if (postImage.Attributes.Contains("cdi_name"))
                    {
                        string name = postImage.Attributes.Contains("cdi_name") ? Convert.ToString(postImage.Attributes["cdi_name"]) : string.Empty;
                        string roleTypeText = postImage.Attributes.Contains("cdi_roletype") ? (postImage.FormattedValues["cdi_roletype"]) : string.Empty;
                        CreateSettlementPartyRecordByRoleType(service, entity, name, roleTypeText);
                    }

                    tracingService.Trace($"Post Operation Settlement UpdateRecord Execution Ended:{DateTime.Now}");
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in Post Operation Settlement UpdateRecord.", ex);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Plugin: {0}", ex.ToString());
                    throw;
                }
            }
        }
        private void CreateSettlementPartyRecordByRoleType(IOrganizationService service, Entity entity, string name,string roleTypeText)
        {
            int roleType = ((OptionSetValue)entity.Attributes["cdi_roletype"]).Value;
            QueryExpression queryExpression = new QueryExpression("cdi_settlementparty");
            queryExpression.ColumnSet.AddColumns(new string[] { "cdi_name", "cdi_roletype" });
            queryExpression.Criteria.AddCondition("cdi_roletype", ConditionOperator.Equal, roleType);
            queryExpression.Criteria.AddCondition("cdi_name", ConditionOperator.Equal, name);

            EntityCollection entityCollection = service.RetrieveMultiple(queryExpression);
            if (entityCollection.Entities.Count > 0)
            {
                throw new InvalidPluginExecutionException("Duplicate Parties are not allowed.");
            }
            else
            {
                CreateSettlementPartyRecord(service, entity, name, roleTypeText);
            }
        }
        private void CreateSettlementPartyRecord(IOrganizationService service, Entity entity, string name, string roleTypeText)
        {
            var roleType = (OptionSetValue)entity.Attributes["cdi_roletype"];
            if (roleType != null)
            {
                Entity settlementParty = new Entity("cdi_settlementparty");
                settlementParty["cdi_name"] = roleTypeText;
                settlementParty["cdi_roletype"] = roleType;
                settlementParty["cdi_settlement"] = new EntityReference(entity.LogicalName, entity.Id);
                service.Create(settlementParty);

                Entity settlement = new Entity("cdi_settlement");
                settlement.Id = entity.Id;
                settlement["cdi_allsettlementpartiessigned"] = false;
                settlement["statuscode"] = new OptionSetValue(1);
                service.Update(settlement);
            }
        }
    }
}

